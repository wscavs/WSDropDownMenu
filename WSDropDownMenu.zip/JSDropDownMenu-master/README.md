# JSDropDownMenu
类似美团的下拉菜单

![image](https://github.com/jsfu/JSDropDownMenu/raw/master/ScreenShots/2015.1.19.5.31.29.png)

![image](https://github.com/jsfu/JSDropDownMenu/raw/master/ScreenShots/2015.1.27.2.00.03.png)

![image](https://github.com/jsfu/JSDropDownMenu/raw/master/ScreenShots/2015.1.27.2.00.06.png)